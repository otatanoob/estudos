/*Fa�a um programa que apresente o menu a seguir, permita ao usu�rio escolher a op��o
desejada, receba os dados necess�rios para executar a opera��o e mostre o resultado.
Verifique a possibilidade de op��o inv�lida e n�o se preocupe com restri��es, como sal�rio
negativo*/

#include <stdio.h>
#include <stdlib.h>
#include <locale.h>

int main()
{
	setlocale(LC_ALL,"Portuguese");
	float salario, imposto;
	float aumento;
	int menu;
	
	do
	{
	printf("1.Imposto");
	printf("\n2.Novo Sal�rio");
	printf("\n3.Classifica��o\n");
	printf("\nDigite a op��o desejada:");
	scanf("%d", &menu); 
	if(menu<1 || menu>3)
	{
		printf("Inv�lido\n\n");
	}
	}while(menu<1 || menu>3);

	


	switch(menu)
	{
		case 1:
			printf("\nDigite o seu sal�rio: ");
			scanf("%f",&salario);
			if(salario<500)
			{
				imposto = salario * 0.05;
				printf("O percentual do imposto � de 5%% totalizando: %.2f",imposto);
			}
			else if( salario >= 500.0 && salario<=850.0)
			{
				imposto = salario * 0.1;
				printf("O percentual do imposto � de 10%% totalizando: %.2f",imposto);
			}
			else if( salario > 850)
			{
				imposto = salario * 0.15;
				printf("O percentual do imposto � de 15%% totalizando: %.2f",imposto);
			}
			break;
		case 2:
			printf("\nDigite o seu sal�rio: ");
			scanf("%f",&salario);
			
			if(salario>1500)
			{
				aumento = salario + 25;
				printf("O novo sal�rio com um aumento de R$25 ficam: %f", aumento);
			}
			else if(salario<=1500 && salario>=750)
			{					aumento = salario + 50;
				printf("O novo sal�rio com um aumento de R$50 ficam: %f", aumento);
			}
			else if(salario<750 && salario>=450)				{
				aumento = salario + 75;
				printf("O novo sal�rio com um aumento de R$75 ficam: %f", aumento);
			}
			else if(salario<450)
			{
				aumento = salario + 100;
				printf("O novo sal�rio com um aumento de R$100 ficam: %f", aumento);
			}
		
			break;
		case 3:
			printf("\nDigite o seu sal�rio: ");
			scanf("%f",&salario);
			
			if(salario<=700)
			{
				printf("Mal remunerado");
			}
			if(salario>700)
			{
				printf("Bem remunerado");
			}
			break;			
	}
	return 0;
}

