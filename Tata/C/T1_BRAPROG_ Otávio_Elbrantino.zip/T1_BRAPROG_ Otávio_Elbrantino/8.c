/*Foi feita uma estat�stica em cinco cidades brasileiras para coletar dados sobre acidentes de
tr�nsito. Foram obtidos os seguintes dados.
a) c�digo da cidade;
b) n�mero de ve�culos de passeio;
c) n�mero de acidentes de tr�nsito com v�timas.
Deseja-se saber:
a) qual � o maior e qual � o menor �ndice de acidentes de tr�nsito e a que cidades pertencem;
b) qual � a m�dia de ve�culos nas cinco cidades juntas;
c) qual � a m�dia de acidentes de tr�nsito nas cidades com menos de 2.000 ve�culos de
passeio. */

#include <stdio.h>
#include <stdlib.h>
#include <locale.h>

int main()
{
	setlocale(LC_ALL,"Portuguese");

	int numCarros[5], numAcidentes[5], i=0, maiorIndice = 0, menorIndice = 0, j=0, k=0;
	float media = 0, mediaMenos = 0;
	
	printf("1.Bragan�a Paulista \n2.Campinas \n3.Vargem \n4.Atibaia \n5.Piracaia\n");
	
	for(i = 0; i <= 4; i++)
	{
		printf("\nEscreva a quantidade de ve�culos da %d� cidade: ", i+1);
		scanf("%d", &numCarros[i]);
		
		printf("Escreva a quantidade de acidentes com v�timas da %d� cidade: ", i+1);
		scanf("%d", &numAcidentes[i]);
		
		if(numAcidentes[i] > numAcidentes[maiorIndice])
		{
			maiorIndice = i;
		}
		if(numAcidentes[i] < numAcidentes[menorIndice])
		{
			menorIndice = i;
		}
	}
	
	printf("\nA cidade com o maior �ndice de acidentes � a %d� (%d acidentes)\n", maiorIndice + 1, numAcidentes[maiorIndice]);
	printf("A cidade com o menor �ndice de acidentes � a %d� (%d acidentes)\n", menorIndice + 1, numAcidentes[menorIndice]);
	
	for(j = 0; j <= 4; j++)
	{
		media += numCarros[j];
		
		if(numCarros[j] < 2000)
		{
			mediaMenos += numAcidentes[j];
			k++;
		}
	}
	
	media = media / 5;
	
	if(k > 0)
	{
		mediaMenos = mediaMenos / k;
	}
	else
	{
		mediaMenos = 0;
	}
	
	printf("\nA m�dia de ve�culos nas cinco cidades juntas �: %.2f\n", media);
	printf("A m�dia de acidentes de tr�nsito nas cidades com menos de 2.000 ve�culos �: %.2f\n", mediaMenos);
	
	return 0;
}

