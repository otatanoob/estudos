/*6) Fa�a um programa que receba o sal�rio inicial de um funcion�rio, calcule e mostre o novo
sal�rio, acrescido de bonifica��o e de aux�lio escola.*/

#include <stdio.h>
#include <stdlib.h>
#include <locale.h>

int main()
{
	setlocale(LC_ALL,"Portuguese");
	
	float salario, bonificacao, aux;
	
	printf("Escreva seu sal�rio: ");
	scanf("%f", &salario);
	
	if(salario<500){
		bonificacao=0.05 * salario;
	} 
	else if(salario>=500 && salario<=1200){
		bonificacao=0.12 * salario;
	}
	else if(salario>1200){
		bonificacao=0;
	}
	
	if(salario<=600){
		aux= 150;
	}
	else if(salario>600){
		aux= 100;
	}
	salario+= bonificacao + aux;
	
	printf("A bonifica��o �: %.2f\n", bonificacao);
	printf("O aux�lio escola � : %.2f\n", aux);
	printf("O sal�rio final �: %.2f",salario);
	return 0;
}
