/*9) Uma empresa possui dez funcion�rios com as seguintes caracter�sticas: c�digo, n�mero de
horas trabalhadas no m�s, turno de trabalho (M � matutino; V � vespertino; ou N �
noturno), categoria (O � oper�rio; ou G � gerente), valor da hora trabalhada. Sabendo-se
que essa empresa deseja informatizar sua folha de pagamento, fa�a um programa que:
a) Leia as informa��es dos funcion�rios, exceto o valor da hora trabalhada, n�o permitindo que
sejam informados turnos e nem categorias inexistentes. Trabalhe sempre com a digita��o
de letras mai�sculas.
b) Calcule o valor da hora trabalhada, conforme a tabela a seguir. Adote o valor de R$ 450,00
para o sal�rio m�nimo.
c) Calcule o sal�rio inicial dos funcion�rios com base no valor da hora trabalhada e no n�mero
de horas trabalhadas.
d) Calcule o valor do aux�lio alimenta��o recebido pelo funcion�rio de acordo com seu sal�rio
inicial, conforme a tabela a seguir.
e) Mostre o c�digo, n�mero de horas trabalhadas, valor da hora trabalhada, sal�rio inicial, aux�lio
alimenta��o e sal�rio final (sal�rio inicial + aux�lio alimenta��o).*/

#include <stdio.h>
#include <stdlib.h>
#include <locale.h>

int main()
{
	setlocale(LC_ALL,"Portuguese");
	
	int i=1, cod;
	float salario, horas, valorHora, salarioFinal, aux;
	const float salarioMinimo = 450.0;
	char categoria, turno;
	
	for(i; i<=10; i++){
		printf("\nQual o c�digo?: ");
		scanf("%d", &cod);
			
		do{
			printf("\nQual a categoria?(O � oper�rio; ou G � gerente): ");
			scanf( " %c", &categoria);
			
			if (categoria != 'O' && categoria != 'G') {
                printf("Categoria inv�lida, tente novamente.\n");
            }
            
		}while(categoria!='O' && categoria!='G');
		
		do{
			printf("\nQual o turno:(M � matutino; V � vespertino; ou N � noturno):");
			scanf(" %c", &turno);
			
			if (turno != 'M' && turno != 'V' && turno != 'N') {
                printf("Turno inv�lido, tente novamente.\n");
            }
		}while(turno!='M' && turno!='V' && turno!='N');
		
		do{
			printf("\nQuantidade de horas trabalhadas: ");
			scanf("%f", &horas);
		}while(horas<=0);
		
	
		if(categoria=='G' && turno== 'N'){
			valorHora= salarioMinimo * 0.18;
		}
		else if(categoria=='G' && (turno== 'M' || turno== 'V')){
			valorHora= salarioMinimo * 0.15;
		}
		else if(categoria=='O' && turno== 'N'){
			valorHora= salarioMinimo * 0.13;
		}
		else if(categoria=='O' && (turno== 'M' || turno== 'V')){
			valorHora= salarioMinimo * 0.10;
		}
		
		salario = horas * valorHora;
		
		if(salario<300){
			aux = salario * 0.20;
		}
		else if(salario>=300 && salario<=600){
			aux = salario * 0.15;
		}
		else if(salario>600){
			aux = salario * 0.05;
		}
		
		salarioFinal = salario + aux;
		
		printf("\nO c�digo do trabalhador �: %d", cod);
		printf("\nN�mero de horas trabalhadas foi: %.2f", horas);
		printf("\nValor da hora trabalhada: %.2f",valorHora);
		printf("\nSal�rio inicial: %.2f",salario);
		printf("\nAux�lio alimenta��o: %.2f", aux);
		printf("\nSal�rio final: %.2f\n",salarioFinal);
		printf("\n------------------------\n");	
	}
	return 0;
}
