/*Pedro comprou um saco de ra��o com peso em quilos. Ele possui dois gatos, para os quais
fornece a quantidade de ra��o em gramas. A quantidade di�ria de ra��o fornecida para cada
gato � sempre a mesma. Fa�a um programa que receba o peso do saco de ra��o e a
quantidade de ra��o fornecida para cada gato, calcule e mostre quanto restar� de ra��o no
saco ap�s cinco dias.*/


#include <stdio.h>
#include <stdlib.h>
#include <locale.h>

int main()
{
	setlocale(LC_ALL, "Portuguese");
	float peso, racaoDiaria, i=1;
	
	printf("Qual o peso em Kg do saco de ra��o?: ");
	scanf("%f", &peso);
	
	printf("Qual a quantidade de ra��o dada a cada gato diariamente em gramas?: ");
	scanf("%f", &racaoDiaria);
	
	peso*= 1000;
	racaoDiaria*=2;
	
	for(i; i<=5; i++)
	{
		peso -= racaoDiaria;
	}
	
	peso /= 1000;
	
	printf("\nA ra��o restante daqui 5 dias sera: %.2f Kg \n", peso);
	
	system("pause");
	return 0;
	
 } 
