/*Fa�a um programa que receba o c�digo correspondente ao cargo de um funcion�rio e seu
sal�rio atual e mostre o cargo, o valor do aumento e seu novo sal�rio. Os cargos est�o na
tabela a seguir.*/

#include <stdio.h>
#include <stdlib.h>
#include <locale.h>

int main()
{
	setlocale(LC_ALL,"Portuguese");
	float salario, salarioFinal, aumento;
	int cod;
	printf("Qual o seu sal�rio atual? :");
	scanf("%f", &salario);
	
	printf("Qual o c�digo de seu cargo? :");
	scanf("%d", &cod);
	
	switch(cod)
	{
		case 1:
			aumento = salario * 0.50;
			salarioFinal = salario + aumento;
			printf("\nEscritu�rio");
			printf("\nO aumento � de 50%%, totalizando: R$%.2f", aumento);
			printf("\nO salario final fica: %.2f",salarioFinal);
			break;
		
		case 2:
			aumento = salario * 0.35;
			salarioFinal = salario + aumento;
			printf("\nSecret�rio");
			printf("\nO aumento � de 35%%, totalizando: R$%.2f", aumento);
			printf("\nO sal�rio final fica: %.2f",salarioFinal);
			break;
		
		case 3:
			aumento = salario * 0.20;
			salarioFinal = salario + aumento;
			printf("\nCaixa");
			printf("\nO aumento � de 20%%, totalizando: R$%.2f", aumento);
			printf("\nO salario final fica: %.2f",salarioFinal);
			break;
		
		case 4:
			aumento = salario * 0.10;
			salarioFinal = salario + aumento;
			printf("\nGerente");
			printf("\nO aumento � de 10%%, totalizando: R$%.2f", aumento);
			printf("\nO salario final fica: %.2f",salarioFinal);
			break;
		
		case 5:
			aumento = salario * 0.0;
			salarioFinal = salario + aumento;
			printf("\nDiretor");
			printf("\nO diretor n�o posssui aumento");
			printf("\nO salario final fica: %.2f",salarioFinal);
			break;
		
	}
	
	
}
